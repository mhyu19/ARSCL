from glob import glob
import numpy as np
import pandas as pd
import torch
from sklearn.model_selection import KFold
import os
import pickle


def load_folds_data(np_data_path, n_folds):
    # files = sorted(glob(os.path.join(np_data_path, "*.pt")))  # 查找文件并排序，glob用于查找符合特定规则的文件路径名，sorted用于排序
    files = sorted(glob(os.path.join(np_data_path, "*.pkl")))
    npzfiles = np.asarray(files, dtype='<U200')  # 将文件路径名转换为numpy数组
    train_files = np.array_split(npzfiles, n_folds)  # 将文件路径名分成n_folds份列表
    folds_data = {}
    for fold_id in range(n_folds):
        subject_files = train_files[fold_id]  # 选取第fold_id份作为验证集
        training_files = list(set(npzfiles) - set(subject_files))  # 除去验证集剩下的作为训练集
        folds_data[fold_id] = [training_files, subject_files]  # 将训练集和验证集放入字典
    return folds_data  # 返回字典


def split_data_KFlod(train_data, train_label,
                     output_dir='E:\\EEG\\code\\PHD_Project\\ARSCL\\data\\FACED\\FACED_Fold') -> None:
    # 分割数据
    kf = KFold(n_splits=12, shuffle=True, random_state=42)
    fold_id = 0  # session1 fold_id = 0, session2 fold_id = 5, session3 fold_id = 10
    for train_index, test_index in kf.split(train_data):
        train_datas, test_data = train_data[train_index], train_data[test_index]
        train_labels, test_labels = train_label[train_index], train_label[test_index]
        dat_dict = dict()
        dat_dict["samples"] = torch.from_numpy(train_datas)
        dat_dict["labels"] = torch.from_numpy(train_labels)
        save_path = os.path.join(output_dir, f'Fold 1{fold_id + 1}')
        if not os.path.exists(save_path):
            os.makedirs(save_path)
        torch.save(dat_dict, os.path.join(save_path, "train.pt"))
        dat_dict = dict()
        dat_dict["samples"] = torch.from_numpy(test_data)
        dat_dict["labels"] = torch.from_numpy(test_labels)
        torch.save(dat_dict, os.path.join(save_path, "val.pt"))
        fold_id += 1


label_a = pd.read_csv('label.txt', header=None)

# %%
label_a = np.array(label_a)
print(label_a.shape)
for i in range(label_a.shape[0]):
    if 0 <= i <= 2:
        label_a[i, 0] = 0
    elif 3 <= i <= 5:
        label_a[i, 0] = 1
    elif 6 <= i <= 8:
        label_a[i, 0] = 2
    elif 9 <= i <= 11:
        label_a[i, 0] = 3
    elif 12 <= i <= 15:
        label_a[i, 0] = 4
    elif 16 <= i <= 18:
        label_a[i, 0] = 5
    elif 19 <= i <= 21:
        label_a[i, 0] = 6
    elif 22 <= i <= 24:
        label_a[i, 0] = 7
    elif 25 <= i <= 27:
        label_a[i, 0] = 8

data_path = 'E:\\EEG\\datasets\\FACED\\EEG_Features\\DE\\'
folds = load_folds_data(data_path, 12)
output_dir = '/data/FACED/FACED_Fold'

faced_data = []
faced_label = []
for file in os.listdir(data_path):
    sub_name = file.split('.')[0]
    sub_num = int(sub_name[3:])
    with open(data_path + file, 'rb') as f:
        data = pickle.load(f)
    all_data = []
    label_all = []
    for i in range(data.shape[2]):
        data_i = data[:, :, i, :]
        all_data.append(data_i)
        label_all.append(label_a)
    train_data = np.concatenate(all_data, axis=0).transpose(0, 2, 1)
    train_labels = np.concatenate(label_all, axis=0).reshape(-1)
    faced_data.append(train_data)
    faced_label.append(train_labels)
faced_all_data = np.concatenate(faced_data, axis=0)
faced_all_label = np.concatenate(faced_label, axis=0)

split_data_KFlod(faced_all_data, faced_all_label)
