from glob import glob
import os
import torch
import numpy as np
from sklearn.model_selection import train_test_split


def load_folds_data(np_data_path, n_folds):
    # files = sorted(glob(os.path.join(np_data_path, "*.pt")))  # 查找文件并排序，glob用于查找符合特定规则的文件路径名，sorted用于排序
    files = sorted(glob(os.path.join(np_data_path, "*.pt")))
    npzfiles = np.asarray(files, dtype='<U200')  # 将文件路径名转换为numpy数组
    train_files = np.array_split(npzfiles, n_folds)  # 将文件路径名分成n_folds份列表
    folds_data = {}
    for fold_id in range(n_folds):
        subject_files = train_files[fold_id]  # 选取第fold_id份作为验证集
        training_files = list(set(npzfiles) - set(subject_files))  # 除去验证集剩下的作为训练集
        folds_data[fold_id] = [training_files, subject_files]  # 将训练集和验证集放入字典
    return folds_data  # 返回字典


data_dir = "../data/EEGConfuse"
n_folds = 1
files = os.listdir(data_dir)
files = np.array([os.path.join(data_dir, i) for i in files if ".pt" in i])
files.sort()
folds = load_folds_data(data_dir, n_folds)
# import pdb; pdb.set_trace()

# few_label_precessing
few_lbl_percentages = [1, 5, 10, 50, 75]

for fold_id in range(len(folds)):
    for percentage in few_lbl_percentages:
        # output_dir = os.path.join(main_output_dir, f"fold_{fold_id}")
        # os.makedirs(output_dir, exist_ok=True)

        # ----------- TRAINing files ------------#
        # import pdb; pdb.set_trace()
        training_files = folds[fold_id][1]

        # load files
        new_file_x = torch.load(training_files[0])["samples"]
        new_file_y = torch.load(training_files[0])["labels"]
        X_val, X_train, y_val, y_train = train_test_split(new_file_x, new_file_y, test_size=percentage / 100,
                                                          random_state=0)
        data_save = dict()
        data_save["samples"] = X_train
        data_save["labels"] = y_train
        torch.save(data_save, os.path.join(data_dir, f"train_{percentage}per.pt"))

    # # load files
    # X_train = np.load(training_files[0])["x"]
    # y_train = np.load(training_files[0])["y"]
    #
    # for np_file in training_files[1:]:
    #     X_train = np.vstack((X_train, np.load(np_file)["x"]))
    #     y_train = np.append(y_train, np.load(np_file)["y"])
    #
    # data_save = dict()
    # X_train = np.transpose(X_train, [0, 2, 1])
    # data_save["samples"] = torch.from_numpy(X_train)
    # data_save["labels"] = torch.from_numpy(y_train)
    # torch.save(data_save, os.path.join(output_dir, f"train_{fold_id}_100per.pt"))

    ######## Validation ##########
    # validation_files = folds[fold_id][1]
    # # load files
    # X_train = np.load(validation_files[1])["samples"]
    # y_train = np.load(validation_files[1])["labels"]
    #
    # for np_file in validation_files[1:]:
    #     X_train = np.vstack((X_train, np.load(np_file)["x"]))
    #     y_train = np.append(y_train, np.load(np_file)["y"])
    #
    # data_save = dict()
    # X_train = np.transpose(X_train, [0, 2, 1])
    # data_save["samples"] = torch.from_numpy(X_train)
    # data_save["labels"] = torch.from_numpy(y_train)
    # torch.save(data_save, os.path.join(output_dir, f"val_{fold_id}.pt"))
