import os
import numpy as np
import torch


def load_data_inde(path, subject, percent_data=0.1):
    x_tr = np.array([])
    y_tr = np.array([])
    x_ts = np.array([])
    y_ts = np.array([])
    for i_subject in os.listdir(path):
        dict_load = np.load(os.path.join(path, (str(i_subject))), allow_pickle=True)
        data = dict_load[()]['sample']  # [:, :, -2:]
        # import pdb; pdb.set_trace()
        label = dict_load[()]['label']

        if i_subject == subject:
            x_ts = data
            y_ts = label
        else:
            if x_tr.shape[0] == 0:
                x_tr = data
                y_tr = label
            else:
                x_tr = np.append(x_tr, data, axis=0)
                y_tr = np.append(y_tr, label, axis=0)
    if percent_data == 0.01:
        num_samples = int(x_tr.shape[0] * percent_data)
        indices = np.random.choice(x_tr.shape[0], num_samples, replace=False)
        x_tr = x_tr[indices]
        y_tr = y_tr[indices]
    if percent_data == 0.05:
        num_samples = int(x_tr.shape[0] * percent_data)
        indices = np.random.choice(x_tr.shape[0], num_samples, replace=False)
        x_tr = x_tr[indices]
        y_tr = y_tr[indices]
    if percent_data == 0.1:
        num_samples = int(x_tr.shape[0] * percent_data)
        indices = np.random.choice(x_tr.shape[0], num_samples, replace=False)
        x_tr = x_tr[indices]
        y_tr = y_tr[indices]
    if percent_data == 0.5:
        num_samples = int(x_tr.shape[0] * percent_data)
        indices = np.random.choice(x_tr.shape[0], num_samples, replace=False)
        x_tr = x_tr[indices]
        y_tr = y_tr[indices]
    if percent_data == 0.75:
        num_samples = int(x_tr.shape[0] * percent_data)
        indices = np.random.choice(x_tr.shape[0], num_samples, replace=False)
        x_tr = x_tr[indices]
        y_tr = y_tr[indices]
    else:
        x_tr = x_tr
        y_tr = y_tr
    x_tr = torch.from_numpy(x_tr)
    y_tr = torch.from_numpy(y_tr)
    x_ts = torch.from_numpy(x_ts)
    y_ts = torch.from_numpy(y_ts)
    train_X_Y = {"samples": x_tr, "labels": y_tr}
    val_X_Y = {"samples": x_ts, "labels": y_ts}
    return train_X_Y, val_X_Y


if __name__ == '__main__':
    path = r'E:\EEG\datasets\SEED\Preprocessed_EEG\S3'
    path_ = r'E:\EEG\code\PHD_Project\ARSCL\data\SEED\SEED_Raw'
    for i_subject in os.listdir(path):
        sub_num = i_subject.split('_')[0]
        train_, val_ = load_data_inde(path, i_subject, percent_data=1.0)
        save_path = os.path.join(path_, f'Fold{sub_num}')
        if not os.path.exists(save_path):
            os.makedirs(save_path)
        torch.save(train_, os.path.join(save_path, 'train.pt'))
        torch.save(val_, os.path.join(save_path, 'val.pt'))
