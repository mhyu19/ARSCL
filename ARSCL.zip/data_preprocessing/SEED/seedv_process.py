import numpy as np
import pickle
from sklearn.model_selection import train_test_split, KFold
import torch
import os
import scipy.io as sio


def split_data(train_data, train_labels, subject_num, output_dir='../../data/SEEDV/SEEDV_SD/') -> None:
    # 分割数据
    # 先将数据分割为训练集和测试验证集，6：4 的比例
    X_train, X_val_test, y_train, y_val_test = train_test_split(train_data, train_labels, test_size=0.4,
                                                                random_state=42)
    save_path = os.path.join(output_dir + f'subject{subject_num}')
    if not os.path.exists(save_path):
        os.makedirs(save_path)

    dat_dict = dict()
    dat_dict["samples"] = torch.from_numpy(X_train)
    dat_dict["labels"] = torch.from_numpy(y_train)
    torch.save(dat_dict, os.path.join(save_path, "../../data/SEED/train.pt"))

    dat_dict = dict()
    dat_dict["samples"] = torch.from_numpy(X_val_test)
    dat_dict["labels"] = torch.from_numpy(y_val_test)
    torch.save(dat_dict, os.path.join(save_path, "../../data/SEED/val.pt"))


def process(data_path):
    for file in os.listdir(data_path):
        if file == 'load_DE_features.ipynb':
            continue
        print('processing:', file)
        subject_num = file.split('_')[0]
        data_npz = np.load(os.path.join(data_path, file))
        data = pickle.loads(data_npz['data'])
        label = pickle.loads(data_npz['label'])
        data_dict = dict()
        for i in range(30, 45):  # 0-15 session1, 15-30 session2, 30-44 session3
            data_dict[str(i)] = data[i].reshape(62, -1, 5)
        sio.savemat(f'E:\\EEG\\datasets\\SEED-V\\S3\\s{subject_num}.mat', data_dict)


def process2(data_path):
    for file in os.listdir(data_path):
        if file == 'load_DE_features.ipynb':
            continue
        print('processing:', file)
        subject_num = file.split('_')[0]
        data_npz = np.load(os.path.join(data_path, file))
        data = pickle.loads(data_npz['data'])
        label = pickle.loads(data_npz['label'])
        session = []
        label_session = []
        for i in range(0, 15):  # 0-15 session1, 15-30 session2, 30-44 session3
            tem_data = data[i].reshape(-1, 62, 5)  # data[i].shape = [num, channels*f] -> [n, 310], label.shape = [n,]
            session.append(tem_data)
            label_session.append(label[i])
        # import pdb; pdb.set_trace()
        session1_data = np.vstack(session)
        session1_label = np.concatenate(label_session)
        split_data(session1_data, session1_label, subject_num)
        print(f'{file} has been processed.')


if __name__ == '__main__':
    path = r'E:\EEG\datasets\SEED-V\EEG_DE_features'
    process2(path)
