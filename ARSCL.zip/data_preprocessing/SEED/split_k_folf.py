from sklearn.model_selection import KFold
import torch
from glob import glob
import os
import numpy as np


def load_folds_data(np_data_path, n_folds):
    # files = sorted(glob(os.path.join(np_data_path, "*.pt")))  # 查找文件并排序，glob用于查找符合特定规则的文件路径名，sorted用于排序
    files = sorted(glob(os.path.join(np_data_path, "*.pt")))
    npzfiles = np.asarray(files, dtype='<U200')  # 将文件路径名转换为numpy数组
    train_files = np.array_split(npzfiles, n_folds)  # 将文件路径名分成n_folds份列表
    folds_data = {}
    for fold_id in range(n_folds):
        subject_files = train_files[fold_id]  # 选取第fold_id份作为验证集
        training_files = list(set(npzfiles) - set(subject_files))  # 除去验证集剩下的作为训练集
        folds_data[fold_id] = [training_files, subject_files]  # 将训练集和验证集放入字典
    return folds_data  # 返回字典


def split_data_KFold(train_X, train_Y, op_dir) -> None:
    # 分割数据
    kf = KFold(n_splits=15, shuffle=False)
    fold_id = 0
    for train_index, test_index in kf.split(train_X):
        train_datas, test_data = train_X[train_index], train_X[test_index]
        train_labels, test_labels = train_Y[train_index], train_Y[test_index]
        dat_dict = dict()
        dat_dict["samples"] = torch.from_numpy(train_datas)
        dat_dict["labels"] = torch.from_numpy(train_labels)
        save_path = os.path.join(op_dir, f'Fold{fold_id + 1}')
        if not os.path.exists(save_path):
            os.makedirs(save_path)
        torch.save(dat_dict, os.path.join(save_path, "train.pt"))
        dat_dict = dict()
        dat_dict["samples"] = torch.from_numpy(test_data)
        dat_dict["labels"] = torch.from_numpy(test_labels)
        torch.save(dat_dict, os.path.join(save_path, "val.pt"))
        fold_id += 1


def get_data(data_dir: str) -> tuple:
    data = torch.load(data_dir)
    return data["data"], data["label"]


if __name__ == '__main__':
    data_path = r"E:\EEG\code\PHD_Project\ARSCL\data\SEEDIV\SEEDIV_DE"
    folds = load_folds_data(data_path, 12)
    output_dir = "../../data/SEED/SEED_Fold"
    # for key in fold_files.keys():
    for fold_id in range(len(folds)):
        train_X = []
        train_Y = []
        val_X = []
        val_Y = []
        train_file = folds[fold_id][0]
        val_file = folds[fold_id][1]
        # val_sub = val_file[0].split("\\")[-1].split(".")[0]
        # import pdb; pdb.set_trace()
        for file in folds[fold_id][0]:
            train_data, train_label = get_data(file)
            train_X.append(train_data)
            train_Y.append(train_label)
        train_dt = np.concatenate(train_X, axis=0)
        train_lb = np.concatenate(train_Y, axis=0)
        for val_f in val_file:
            val_data, val_label = get_data(val_f)
            val_X.append(val_data)
            val_Y.append(val_label)
        val_dt = np.concatenate(val_X, axis=0)
        val_lb = np.concatenate(val_Y, axis=0)
        train_dict = dict()
        train_dict["samples"] = torch.from_numpy(train_dt)
        train_dict["labels"] = torch.from_numpy(train_lb)
        val_dict = dict()
        val_dict["samples"] = torch.from_numpy(val_dt)
        val_dict["labels"] = torch.from_numpy(val_lb)
        save_path = os.path.join(output_dir, f'Fold{fold_id + 1}')
        if not os.path.exists(save_path):
            os.makedirs(save_path)
        torch.save(train_dict, os.path.join(save_path, "train.pt"))
        torch.save(val_dict, os.path.join(save_path, "val.pt"))

