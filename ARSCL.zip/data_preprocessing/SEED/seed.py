import os
import numpy as np
from scipy.io import loadmat
import einops


def extend_normal(sample):
    for i in range(len(sample)):
        features_min = np.min(sample[i])
        features_max = np.max(sample[i])
        sample[i] = (sample[i] - features_min) / (features_max - features_min)
    return sample


def eeg_data(label_list, trial_list, raw_path, path):
    if not os.path.exists(path):
        os.makedirs(path)

    for subject in os.listdir(raw_path):
        subject_name = str(subject).strip('.mat')

        data = np.array([])  # 存储每一个subject的数组
        label = np.array([])
        clip = None
        frequency = "de_LDS"
        count = 0

        for i in trial_list:
            dataKey = frequency + str(i + 1)
            metaData = np.array((loadmat(os.path.join(raw_path, subject_name), verify_compressed_data_integrity=False)[
                dataKey])).astype('float')  # 读取到原始的三维元数据
            trMetaData = einops.rearrange(metaData, 'w h c -> h w c')  # (42,62,5)

            count += 1
            x = np.array(trMetaData)
            y = np.array([label_list[i], ] * x.shape[0])

            if data.shape[0] == 0:
                data = x
                label = y
            else:
                data = np.append(data, x, axis=0)
                label = np.append(label, y, axis=0)

            if count == 16:
                clip = data.shape[0]

        # 对于data进行min-max归一化
        data = extend_normal(data)

        dict_dt = {'sample': data, 'label': label, 'clip': clip}
        np.save(os.path.join(path, (str(subject).strip('.mat') + ".npy")), dict_dt)


if __name__ == "__main__":
    """Resave all data to .npy"""
    raw_data_path = r"E:\EEG\datasets\SEED\ExtractedFeatures"
    data_path = r"E:\EEG\code\PHD_Project\ARSCL\data\SEED\SEED_Fold"  # 存储合并的两种数据
    # 对于seed4数据集，由于类别的排布不均匀，所以对于每个session的trial需要进行调整
    session = 1
    # label_list = [1, 2, 3, 0, 2, 0, 0, 1, 0, 1, 2, 1, 1, 1, 2, 3, 2, 2, 3, 3, 0, 3, 0, 3]
    label_list = [1, 0, 2, 2, 0, 1, 2, 0, 1, 1, 0, 2, 0, 1, 2]
    # 选取每种类型的后2个trial用于测试
    # trial_list = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 14, 15, 18, 19, 12, 13, 16, 17, 20, 21, 22, 23]
    trial_list = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14]
    print(f"Load session {session}...")
    eeg_data(label_list, trial_list, os.path.join(raw_data_path, str(session)), os.path.join(data_path, str(session)))

    session = 2
    # label_list = [2, 1, 3, 0, 0, 2, 0, 2, 3, 3, 2, 3, 2, 0, 1, 1, 2, 1, 0, 3, 0, 1, 3, 1]
    label_list = [1, 0, 2, 2, 0, 1, 2, 0, 1, 1, 0, 2, 0, 1, 2]
    # 选取每种类型的后2个trial用于测试
    # trial_list = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 13, 14, 15, 17, 12, 16, 18, 19, 20, 21, 22, 23]
    trial_list = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14]
    print(f"Load session {session}...")
    eeg_data(label_list, trial_list, os.path.join(raw_data_path, str(session)), os.path.join(data_path, str(session)))

    session = 3
    # label_list = [1, 2, 2, 1, 3, 3, 3, 1, 1, 2, 1, 0, 2, 3, 3, 0, 2, 3, 0, 0, 2, 0, 1, 0]
    label_list = [1, 0, 2, 2, 0, 1, 2, 0, 1, 1, 0, 2, 0, 1, 2]
    # 选取每种类型的后2个trial用于测试
    # trial_list = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 11, 12, 13, 15, 18, 19, 10, 14, 16, 17, 20, 21, 22, 23]
    trial_list = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14]
    print(f"Load session {session}...")
    eeg_data(label_list, trial_list, os.path.join(raw_data_path, str(session)), os.path.join(data_path, str(session)))

    print(f"Resave data succeed.")