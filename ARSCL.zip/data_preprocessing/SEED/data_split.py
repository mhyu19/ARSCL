import numpy as np
import torch
from sklearn.model_selection import train_test_split
from sklearn.utils import shuffle
from sklearn.preprocessing import StandardScaler
import scipy.io
import os

scaler = StandardScaler()


def get_file_path(root_path, file_list, dir_list):
    # 获取该目录下所有的文件名称和目录名称
    dir_or_files = sorted(os.listdir(root_path))
    for dir_file in dir_or_files:
        # 获取目录或者文件的路径
        dir_file_path = os.path.join(root_path, dir_file)
        # 判断该路径为文件还是路径
        if os.path.isdir(dir_file_path):
            dir_list.append(dir_file_path)
            # 递归获取所有文件和目录的路径
            get_file_path(dir_file_path, file_list, dir_list)
        else:
            file_list.append(dir_file_path)
    return dir_list, file_list


# 滑动窗口获取数据，2秒重叠
def get_seq_data(data_temp, label_temp, window_size):
    window = window_size
    step_size = window_size // 2
    data_list = []
    outshots = []
    label = []

    start = 0
    while start + window < len(data_temp):
        data_list.append(data_temp[start:start + window])
        outshots.append(data_temp[start + window])
        label.append(label_temp[0])
        start = start + step_size
        continue
    data_np = np.array(data_list)
    outshot_np = np.array(outshots)
    label_np = np.array(label)
    data_tensor = torch.Tensor(data_np)
    outshot_data = torch.Tensor(outshot_np)
    # data_tensor = torch.cat((data_tensor, outshot_data.unsqueeze(1)), dim=1)
    target_label = torch.LongTensor(label_np)
    return data_tensor, target_label


def get_train_test_clip(root_path, sub, clip_num_list, window_size):
    file_list = []
    dir_list = []
    file_list_seq = []
    get_file_path(root_path, file_list, dir_list)
    file_list_seq.extend(file_list[6:-1])
    file_list_seq.extend(file_list[:6])
    file_list_seq.extend([file_list[-1]])  # 排序，1-15， 否则为10-15 1-9
    # file_list_seq.extend(file_list[:2])
    # file_list_seq.extend(file_list[9:])
    # file_list_seq.extend(file_list[2:9])
    first_trial_file_list = [ii for n, ii in enumerate(file_list_seq) if n % 1 == 0]  # 筛选第一次试验的数据
    label = scipy.io.loadmat(first_trial_file_list[-1])  # 读取label
    # label = scipy.io.loadmat(first_trial_file_list[0])  # 读取label
    file = first_trial_file_list[int(sub) - 1]
    # file = first_trial_file_list[int(sub)]
    data = scipy.io.loadmat(file)
    x_ = np.zeros((0, window_size, 62, 5))
    y_ = np.zeros(0)
    train_x = []
    train_y = []
    test_x = []
    test_y = []
    for ii in range(1, 16):
        # 对单个受试者的单个影片数据进行处理
        # import pdb; pdb.set_trace()
        data_temp = data['de_movingAve' + str(ii)]
        # data_temp = data[str(ii)]  # SEEDV
        data_temp = scaler.fit_transform(data_temp.transpose(1, 2, 0).reshape(-1, 62)
                                         ).reshape(-1, 5, 62).transpose(0, 2, 1)
        label_use = label['label'][:, int(ii) - 1]
        # label_use = label['label'][int(ii) - 1, :]  # SEEDV
        if label_use < 0:
            label_use = 2
        label_temp = np.array([label_use]).repeat(data_temp.shape[0])
        data_seq, label_seq = get_seq_data(data_temp, label_temp, window_size)
        subject_data = np.vstack((x_, data_seq))
        subject_label = np.append(y_, label_seq)
        if ii in clip_num_list:
            train_x.append(subject_data)
            train_y.extend(subject_label)
        else:
            test_x.append(subject_data)
            test_y.extend(subject_label)
    # subject_data = np.vstack(subject_data)
    # subject_label = np.hstack(subject_label)
    # x_train, x_test, y_train, y_test = train_test_split(subject_data, subject_label, test_size=0.4, random_state=42)
    x_train = np.vstack(train_x)
    y_train = np.hstack(train_y)
    x_test = np.vstack(test_x)
    y_test = np.hstack(test_y)
    x_train = torch.Tensor(x_train).permute(0, 1, 3, 2)
    x_test = torch.Tensor(x_test).permute(0, 1, 3, 2)
    y_train = torch.LongTensor(y_train)
    y_test = torch.LongTensor(y_test)
    x_train = shuffle(x_train, random_state=2022)
    x_test = shuffle(x_test, random_state=2022)
    y_train = shuffle(y_train, random_state=2022)
    y_test = shuffle(y_test, random_state=2022)
    return x_train, y_train, x_test, y_test


def get_train_test_sub(root_path, sub, window_size):
    file_list = []
    dir_list = []
    file_list_seq = []
    get_file_path(root_path, file_list, dir_list)
    file_list_seq.extend(file_list[6:-1])
    file_list_seq.extend(file_list[:6])
    file_list_seq.extend([file_list[-1]])  # 排序，1-15， 否则为10-15 1-9
    # file_list_seq.extend(file_list[:2])
    # file_list_seq.extend(file_list[9:])
    # file_list_seq.extend(file_list[2:9])
    first_trial_file_list = [ii for n, ii in enumerate(file_list_seq) if n % 1 == 0]  # 筛选第一次试验的数据
    x_ = np.zeros((0, window_size, 62, 5))
    y_ = np.zeros(0)
    label = scipy.io.loadmat(first_trial_file_list[-1])  # 读取label
    # label = scipy.io.loadmat(first_trial_file_list[0])  # 读取label
    # import pdb; pdb.set_trace()
    train_x = []
    train_y = []
    test_x = []
    test_y = []
    file = first_trial_file_list[int(sub) - 1]
    # file = first_trial_file_list[int(sub)]
    data = scipy.io.loadmat(file)  # 单个受试者数据
    for j in [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15]:
        for split in range(1, 16):
            # import pdb; pdb.set_trace()
            data_temp = data['de_movingAve' + str(split)]   # SEED IV
            # data_temp = data[str(ii)]  # SEEDV
            data_temp = scaler.fit_transform(data_temp.transpose(1, 2, 0).reshape(-1, 62)
                                             ).reshape(-1, 5, 62).transpose(0, 2, 1)
            label_use = label['label'][:, int(split) - 1]
            # label_use = label['label'][int(ii - 30) - 1, :]  # SEEDV
            if label_use < 0:
                label_use = 2
            label_temp = np.array([label_use]).repeat(data_temp.shape[0])
            data_seq, label_seq = get_seq_data(data_temp, label_temp, window_size)  # 滑动窗口提取特征
            # 滑动窗口获取数据， 将维度（m, 62, 5）转换为（n, 6, 62, 5）
            subject_data = np.vstack((x_, data_seq))
            subject_label = np.append(y_, label_seq)  # 单个受试者数据
            if j != sub:
                train_x.append(subject_data)
                train_y.extend(subject_label)
            else:
                test_x.append(subject_data)
                test_y.extend(subject_label)
    x_train = np.vstack(train_x)
    y_train = np.hstack(train_y)
    x_test = np.vstack(test_x)
    y_test = np.hstack(test_y)

    x_train = torch.Tensor(x_train).permute(0, 1, 3, 2)  # [:, :, -4:]
    x_test = torch.Tensor(x_test).permute(0, 1, 3, 2)  # [:, :, -4:]
    y_train = y_train.flatten()
    y_test = y_test.flatten()
    return x_train, y_train, x_test, y_test


if __name__ == '__main__':
    seed_path = r"E:\EEG\code\PHD_Project\ARSCL\data\SEED\Graph\raw\subject10.pt"
    # seediv_path = r'E:\EEG\datasets\SEED_IV\eeg_feature_smooth\1'
    # seedv_path = r'E:\EEG\datasets\SEED-V\S1'
    save_paths = r'E:\EEG\code\PHD_Project\ARSCL\data\SEED\SEED_Fold'
    # all_subject_data = []
    # all_subject_label = []
    # test_data = []
    # test_label = []
    train_list = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 12, 14, 15]
    tset_list = [10, 11, 12, 13, 14, 15]
    data = torch.load(seed_path)
    data_x, data_y = data['data'], data['label']
    X_train, X_val_test, y_train, y_val_test = train_test_split(data_x, data_y, test_size=0.4,
                                                                shuffle=False)

    # for i in range(1, 16):
    #     print(f'subject{i}')
    #     x_train_, y_train_, x_test_, y_test_ = get_train_test_sub(seed_path, i, 6)  # subject-independent
    #     # x_train_, y_train_, x_test_, y_test_ = get_train_test_clip(seed_path,
    #     #                                                            i, [1, 2, 3, 4, 5, 6, 7, 8, 9], 6)
    #     # subject-dependent
    #     # if i <=8:
    #     #     all_subject_data.append(x_train_)
    #     #     all_subject_data.append(x_test_)
    #     #     all_subject_label.extend(y_train_)
    #     #     all_subject_label.extend(y_test_)
    #     # else:
    #     #     test_data.append(x_train_)
    #     #     test_data.append(x_test_)
    #     #     test_label.extend(y_train_)
    #     #     test_label.extend(y_test_)
    data_dict = dict()
    data_dict['samples'] = X_train
    data_dict['labels'] = y_train
    save_path = os.path.join(save_paths + f'\\Fold11')
    if not os.path.exists(save_path):
        os.makedirs(save_path)
    torch.save(data_dict, os.path.join(save_path, "train.pt"))
    data_dict = dict()
    data_dict['samples'] = X_val_test
    data_dict['labels'] = y_val_test
    torch.save(data_dict, os.path.join(save_path, "val.pt"))
    # all_subject_data = torch.cat(all_subject_data, dim=0)
    # all_subject_label = torch.LongTensor(all_subject_label)
    # test_data = torch.cat(test_data, dim=0)
    # test_label = torch.LongTensor(test_label)
    # data_dict = dict()
    # data_dict['samples'] = all_subject_data
    # data_dict['labels'] = all_subject_label
    # torch.save(data_dict, os.path.join(save_paths, "val.pt"))
    # data_dict = dict()
    # data_dict['samples'] = test_data
    # data_dict['labels'] = test_label
    # torch.save(data_dict, os.path.join(save_paths, "test.pt"))