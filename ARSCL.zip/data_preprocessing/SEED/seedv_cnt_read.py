import numpy as np
import mne
import os
import scipy.io as sio
import torch


def get_file_path(root_path, file_lst, dir_lst):
    # 获取该目录下所有的文件名称和目录名称
    dir_or_files = sorted(os.listdir(root_path))
    for dir_file in dir_or_files:
        # 获取目录或者文件的路径
        dir_file_path = os.path.join(root_path, dir_file)
        # 判断该路径为文件还是路径
        if os.path.isdir(dir_file_path):
            dir_lst.append(dir_file_path)
            # 递归获取所有文件和目录的路径
            get_file_path(dir_file_path, file_lst, dir_lst)
        else:
            file_lst.append(dir_file_path)
    return dir_lst, file_lst


def read_data(data_path):
    eeg_raw = mne.io.read_raw_cnt(data_path)
    # check channel names
    ch_names = eeg_raw.ch_names
    # drop non-used channels
    useless_ch = ['M1', 'M2', 'VEO', 'HEO']
    eeg_raw.drop_channels(useless_ch)
    new_ch = eeg_raw.ch_names
    # get the data matrix
    data_matrix = eeg_raw.get_data()
    # with file "trial_start_end_timestamp.txt", you can split the data into different trials
    start_second = [30, 132, 287, 555, 773, 982, 1271, 1628, 1730, 2025, 2227, 2435, 2667, 2932, 3204]
    end_second = [102, 228, 524, 742, 920, 1240, 1568, 1697, 1994, 2166, 2401, 2607, 2901, 3172, 3359]
    sample_freq = 1000
    data_dict = {}
    for i in range(len(start_second)):
        data_trial_i = data_matrix[:, start_second[i] * sample_freq: end_second[i] * sample_freq]
        data_dict[f'trial{i}'] = data_trial_i
    return data_dict


if __name__ == "__main__":
    seedv_path = r'E:\EEG\datasets\SEED_V\SEED-V\EEG_raw'
    save_paths = '../../data/SEEDV/SEEDV/'
    file_list = []
    dir_list = []
    file_list_seq = []
    get_file_path(seedv_path, file_list, dir_list)
    file_list_seq.extend(file_list[7 * 3:-1])
    file_list_seq.extend(file_list[:7 * 3])
    # file_list_seq.extend([file_list[-1]])  # 排序，1-15， 否则为10-15 1-9
    first_trial_file_list = [ii for n, ii in enumerate(file_list_seq) if n % 3 == 0]  # 筛选第一次试验的数据
    # import pdb; pdb.set_trace()
    subject_list = first_trial_file_list
    for index, file in enumerate(subject_list):
        print(file)
        dt_dict = read_data(file)
        sio.savemat(os.path.join(save_paths, f'subject{index + 1}.mat'), dt_dict)
