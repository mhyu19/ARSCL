import torch
from torch.utils.data import DataLoader
from torch.utils.data import Dataset
import os
import numpy as np
from .augmentations import DataTransform


class Load_Dataset(Dataset):
    # Initialize  data
    def __init__(self, dataset, config, training_mode):
        super(Load_Dataset, self).__init__()
        self.training_mode = training_mode

        X_train = dataset["samples"]
        y_train = dataset["labels"].reshape(-1)
        if len(X_train.shape) < 3:
            X_train = X_train.unsqueeze(2)

        # if X_train.shape.index(min(X_train.shape)) != 1:  # make sure the Channels in second dim  确保通道维度在第二维
        #     X_train = X_train.permute(0, 2, 1)

        if isinstance(X_train, np.ndarray):
            self.x_data = torch.from_numpy(X_train)
            self.y_data = torch.from_numpy(y_train).long()
        else:
            self.x_data = X_train
            self.y_data = y_train

        self.len = X_train.shape[0]
        if training_mode == "self_supervised":  # no need to apply Augmentations in other modes 如果是自监督模式，需要数据增强
            self.aug1, self.aug2 = DataTransform(self.x_data, config)

    def __getitem__(self, index):
        if self.training_mode == "self_supervised":
            return self.x_data[index], self.y_data[index], self.aug1[index], self.aug2[index]
        else:
            return self.x_data[index], self.y_data[index], self.x_data[index], self.x_data[index]

    def __len__(self):
        return self.len


def data_generator_cv(data_path, configs, training_mode, data_name, fold_id, training_per):
    _path = os.path.join(data_path, f'{data_name}_Fold')
    if training_per == 100:
        train_dataset = torch.load(os.path.join(_path, f"Fold{fold_id}/train.pt"))
        valid_dataset = torch.load(os.path.join(_path, f"Fold{fold_id}/val.pt"))
    else:
        train_dataset = torch.load(os.path.join(_path, f"Fold{fold_id}/train_{training_per}per.pt"))
        valid_dataset = torch.load(os.path.join(_path, f"Fold{fold_id}/val.pt"))
    train_dataset = Load_Dataset(train_dataset, configs, training_mode)
    valid_dataset = Load_Dataset(valid_dataset, configs, training_mode)

    train_loader = torch.utils.data.DataLoader(dataset=train_dataset, batch_size=configs.batch_size,
                                               shuffle=True, drop_last=configs.drop_last,
                                               num_workers=0)
    valid_loader = torch.utils.data.DataLoader(dataset=valid_dataset, batch_size=configs.batch_size,
                                               shuffle=True, drop_last=configs.drop_last,
                                               num_workers=0)

    return train_loader, valid_loader


def data_generator(data_path, configs, training_mode, training_per):
    if training_per == 100:
        train_dataset = torch.load(os.path.join(data_path, "train.pt"))
        valid_dataset = torch.load(os.path.join(data_path, "test.pt"))
        test_dataset = torch.load(os.path.join(data_path, "test.pt"))
    else:
        train_dataset = torch.load(os.path.join(data_path, f"train_{training_per}per.pt"))
        valid_dataset = torch.load(os.path.join(data_path, "val.pt"))
        test_dataset = torch.load(os.path.join(data_path, "test.pt"))

    train_dataset = Load_Dataset(train_dataset, configs, training_mode)
    valid_dataset = Load_Dataset(valid_dataset, configs, training_mode)
    test_dataset = Load_Dataset(test_dataset, configs, training_mode)

    train_loader = torch.utils.data.DataLoader(dataset=train_dataset, batch_size=configs.batch_size,
                                               shuffle=True, drop_last=configs.drop_last,
                                               num_workers=0)
    valid_loader = torch.utils.data.DataLoader(dataset=valid_dataset, batch_size=configs.batch_size,
                                               shuffle=False, drop_last=configs.drop_last,
                                               num_workers=0)

    test_loader = torch.utils.data.DataLoader(dataset=test_dataset, batch_size=configs.batch_size,
                                              shuffle=False, drop_last=False,
                                              num_workers=0)

    return train_loader, valid_loader, test_loader


