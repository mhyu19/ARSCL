import numpy as np
import torch


def DataTransform(sample, config):
    if config.datatype == "DE":
        # aug1 = channels_dropout(sample)
        aug1 = sample
        # aug2 = channels_value_change(sample)
        aug2 = sample
    else:
        aug1 = scaling(sample, config.augmentation.jitter_scale_ratio)
        # aug1 = sample
        aug2 = jitter(permutation(sample, max_segments=config.augmentation.max_seg), config.augmentation.jitter_ratio)
        # aug2 = sample
    return aug1, aug2


def jitter(x, sigma=0.8):
    # 加一个随机数
    # https://arxiv.org/pdf/1706.00527.pdf
    return x + np.random.normal(loc=0., scale=sigma, size=x.shape)


def scaling(x, sigma=1.1):
    # https://arxiv.org/pdf/1706.00527.pdf
    factor = np.random.normal(loc=2., scale=sigma, size=(x.shape[0], x.shape[2]))
    ai = []
    for i in range(x.shape[1]):
        xi = x[:, i, :]
        ai.append(np.multiply(xi, factor[:, :])[:, np.newaxis, :])
    return np.concatenate(ai, axis=1)


def permutation(x, max_segments=5, seg_mode="random"):
    # 目的是将数据片段打乱，在组合回来。
    # 单次所有数据增强shape: (data_length, channels, features_len)
    orig_steps = np.arange(x.shape[2])
    num_segs = np.random.randint(1, max_segments, size=(x.shape[0]))  # 生成x.shape[0]个随机数，范围在1-max_segments之间
    ret = np.zeros_like(x)
    for i, pat in enumerate(x):
        if num_segs[i] > 1:
            if seg_mode == "random":
                split_points = np.random.choice(x.shape[2] - 2, num_segs[i] - 1,
                                                replace=False)  # 生成num_segs[i]-1个随机数，范围在0-x.shape[2]-2之间
                split_points.sort()  # 对得到的数组排序
                splits = np.split(orig_steps, split_points)  # 将orig_steps分为m个数组，位置按照split_points
            else:
                splits = np.array_split(orig_steps, num_segs[i])
            warp = np.concatenate(np.random.permutation(splits)).ravel()
            ret[i] = pat[0, warp]
        else:
            ret[i] = pat
    return torch.from_numpy(ret)


def channels_dropout(x, max_channels_drop=5):
    data_length, band_feature, channels = x.size()
    if channels <= max_channels_drop:
        assert False, "Number of channels is less than the number of channels to drop"
    drop_channels = np.random.choice(channels, max_channels_drop, replace=True)
    for drop in drop_channels:
        x[:, :, drop] = 0.5
    return x


def channels_value_change(x, max_channels_drop=10):
    data_length, band_feature, channels = x.size()
    if data_length <= max_channels_drop:
        assert False, "Number of channels is less than the number of channels to drop"
    drop_channels = np.random.choice(data_length, max_channels_drop, replace=True)
    for drop in drop_channels:
        x[drop, :, :] = 0.5
    return x
