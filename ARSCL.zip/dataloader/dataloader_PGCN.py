import os

import torch
from torch.utils.data import Dataset
import numpy as np
from dataloader.augmentations import DataTransform


class Load_Dataset(Dataset):
    # Initialize  data
    def __init__(self, dataset, config, training_mode):
        super(Load_Dataset, self).__init__()
        self.training_mode = training_mode

        X_train = dataset["samples"]
        y_train = dataset["labels"].reshape(-1)
        if len(X_train.shape) < 3:
            X_train = X_train.unsqueeze(2)

        # if X_train.shape.index(min(X_train.shape)) != 1:  # make sure the Channels in second dim  确保通道维度在第二维
        #     X_train = X_train.permute(0, 2, 1)

        if isinstance(X_train, np.ndarray):
            self.x_data = torch.Tensor(X_train)
            self.y_data = torch.Tensor(y_train).long()
        else:
            self.x_data = X_train
            self.y_data = y_train

        self.len = X_train.shape[0]
        if training_mode == "self_supervised":  # no need to apply Augmentations in other modes 如果是自监督模式，需要数据增强
            self.aug1, self.aug2 = DataTransform(self.x_data, config)

    def __getitem__(self, index):
        if self.training_mode == "self_supervised":
            return self.x_data[index], self.y_data[index], self.aug1[index], self.aug2[index]
        else:
            return self.x_data[index], self.y_data[index], self.x_data[index], self.x_data[index]

    def __len__(self):
        return self.len


def load_data_de(path, subject):
    data_path = os.path.join(path, subject)
    # import pdb;pdb.set_trace()
    file = os.listdir(data_path)[0]
    dict_load = np.load(os.path.join(data_path, file), allow_pickle=True)
    data = dict_load[()]['sample']
    label = dict_load[()]['label']
    split_index = dict_load[()]["clip"]

    x_tr = data[:split_index]
    x_ts = data[split_index:]
    y_tr = label[:split_index]
    y_ts = label[split_index:]
    train_X_Y = {"samples": x_tr, "labels": y_tr}
    val_X_Y = {"samples": x_ts, "labels": y_ts}
    return train_X_Y, val_X_Y


def load_data_inde(path, subjects):
    x_tr = np.array([])
    y_tr = np.array([])
    x_ts = np.array([])
    y_ts = np.array([])
    for i_subject in os.listdir(path):
        dict_load = np.load(os.path.join(path, (str(i_subject))), allow_pickle=True)
        data = dict_load[()]['sample']
        label = dict_load[()]['label']

        if i_subject == subjects:
            x_ts = data
            y_ts = label
        else:
            if x_tr.shape[0] == 0:
                x_tr = data
                y_tr = label
            else:
                x_tr = np.append(x_tr, data, axis=0)
                y_tr = np.append(y_tr, label, axis=0)

    train_X_Y = {"samples": x_tr, "labels": y_tr}
    val_X_Y = {"samples": x_ts, "labels": y_ts}
    return train_X_Y, val_X_Y


if __name__ == '__main__':
    data_path = 'E:\\EEG\\code\\PHD_Project\\ARSCL\\data\\SEEDIV\\npy_data\\1'
    subject = 1
    data_label = load_data_de(data_path, subject)
    print(data_label)
