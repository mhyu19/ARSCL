import torch
import numpy as np
import scipy.io as sio


def smooth_moving_average(data, filtLen):
    # data: [n_channs, n_points]
    if filtLen == 1:
        data_smoothed = data
    else:
        data_smoothed = np.zeros(data.shape)
        for i in range(data.shape[1]):
            if i < filtLen // 2:
                data_smoothed[:, i] = np.mean(data[:, :i + filtLen // 2], axis=1)
            elif i > data.shape[1] - filtLen // 2:
                data_smoothed[:, i] = np.mean(data[:, i - filtLen // 2:], axis=1)
            else:
                data_smoothed[:, i] = np.mean(data[:, i - filtLen // 2: i + filtLen // 2], axis=1)
    return data_smoothed


class TrainSampler_sub():
    def __init__(self, n_subs_all, n_samples, batch_size=240, n_subs=10):
        self.n_subs = n_subs
        self.n_subs_all = n_subs_all
        # Number of data points per session
        self.batch_size = batch_size
        self.n_samples_sum = int(np.sum(n_samples))
        self.n_samples_per_sub = int(batch_size / n_subs)

        ind_all = np.zeros((n_subs_all, self.n_samples_sum))
        for i in range(n_subs_all):
            tmp = np.arange(self.n_samples_sum) + i * self.n_samples_sum
            np.random.shuffle(tmp)
            ind_all[i, :] = tmp
        np.random.shuffle(ind_all)
        self.ind_all = ind_all

        # self.n_times = int(n_subs_all * self.n_samples_sum // batch_size)
        self.n_times_sub = int(n_subs_all / n_subs)
        self.n_times_vid = int(self.n_samples_sum / self.n_samples_per_sub)

    def __len__(self):
        return self.n_times_sub * self.n_times_vid

    def __iter__(self):
        for i in range(self.n_times_vid):
            for j in range(self.n_times_sub):
                ind_sel = self.ind_all[j * self.n_subs: (j + 1) * self.n_subs,
                          self.n_samples_per_sub * i: self.n_samples_per_sub * (i + 1)]
                ind_sel = ind_sel.reshape(-1)
                batch = torch.LongTensor(ind_sel)
                # print(batch)
                yield batch


def load_srt_pretrainFeat(datadir, channel_norm, timeLen, timeStep, isFilt, filtLen, label_type):
    if label_type == 'cls2':
        n_samples = np.ones(24).astype(np.int32) * 30
    else:
        n_samples = np.ones(28).astype(np.int32) * 30

    for i in range(len(n_samples)):
        n_samples[i] = int((n_samples[i] - timeLen) / timeStep + 1)

    if datadir[-4:] == '.npy':
        data = np.load(datadir)
        data[data < -10] = -5
    elif datadir[-4:] == '.mat':
        data = sio.loadmat(datadir)['de_lds']
        print('isnan total:', np.sum(np.isnan(data)))
        data[np.isnan(data)] = -8
        # data[data < -8] = -8

    # data_use = data[:, np.max(data, axis=0)>1e-6]
    # data = data.reshape(45, int(np.sum(n_samples)), 256)
    print(data.shape)
    print(np.min(data), np.median(data))

    n_samples_cum = np.concatenate((np.array([0]), np.cumsum(n_samples)))
    if isFilt:
        print('filtLen', filtLen)
        data = data.transpose(0, 2, 1)
        for i in range(data.shape[0]):
            for vid in range(len(n_samples)):
                data[i, :, int(n_samples_cum[vid]): int(n_samples_cum[vid + 1])] = smooth_moving_average(
                    data[i, :, int(n_samples_cum[vid]): int(n_samples_cum[vid + 1])], filtLen)
        data = data.transpose(0, 2, 1)

    # Normalization for each sub
    if channel_norm:
        print('subtract mean and divided by var')
        for i in range(data.shape[0]):
            # data[i,:,:] = data[i,:,:] - np.mean(data[i,:,:], axis=0)
            data[i, :, :] = (data[i, :, :] - np.mean(data[i, :, :], axis=0)) / (np.std(data[i, :, :], axis=0) + 1e-3)

    if label_type == 'cls2':
        label = [0] * 12
        label.extend([1] * 12)

    elif label_type == 'cls9':
        label = [0] * 3
        for i in range(1, 4):
            label.extend([i] * 3)
        label.extend([4] * 4)
        for i in range(5, 9):
            label.extend([i] * 3)
        print(label)

    elif label_type == 'cls3':
        label = [0] * 12
        label.extend([1] * 4)
        label.extend([2] * 12)
        print(label)

    label_repeat = []
    for i in range(len(label)):
        label_repeat = label_repeat + [label[i]] * n_samples[i]
    return data, label_repeat, n_samples
