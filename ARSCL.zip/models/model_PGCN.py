import argparse
import os
from models.node_location import convert_dis_m, get_ini_dis_m, return_coordinates
import torch.nn as nn
import torch.nn.functional as F
from models.layer_PGCN import LocalLayer, MesoLayer, GlobalLayer
import torch
from torch.nn.parameter import Parameter
import numpy as np
from models.utils import normalize_adj
from config_files.SEED_Configs import Config as Configs


# torch.set_printoptions(profile="full")
def stratified_norm(x):
    mu = torch.mean(x, 0).unsqueeze(0)
    std = torch.std(x, 0).unsqueeze(0)
    return (x - mu) / (std + 1e-8)


class PGCN(nn.Module):
    """
    GCN 62*5 --> 62*(2+4+6+8)
    """

    def __init__(self, configs, local_adj, coor, training_model="self_supervised"):
        super(PGCN, self).__init__()

        self.module = configs.modules
        self.training_model = training_model
        self.nclass = configs.num_classes
        self.dropout = configs.dropout
        self.l_relu = configs.lr
        self.adj = local_adj
        self.coordinate = coor
        # self.local_embed = nn.Linear(1, 5)  # 将原始的特征作为meso层的输入
        # Code for PGCN
        # Local GCN
        self.local_gcn_1 = LocalLayer(configs.in_feature, 10, True)
        self.local_gcn_2 = LocalLayer(10, 15, True)
        # self.local_gcn_3 = LocalLayer(15, 15, True)
        # self.local_gcn_4 = LocalLayer(15, 15, True)
        # self.local_gcn_5 = LocalLayer(15, 10, True)
        # self.local_gcn_6 = LocalLayer(10, 20, True)
        # Meso
        self.meso_embed = nn.Linear(5, 30)  # 将原始的特征拓展后作为meso层的输入
        self.meso_layer_1 = MesoLayer(subgraph_num=7, num_heads=6, coordinate=self.coordinate, trainable_vector=78)
        self.meso_layer_2 = MesoLayer(subgraph_num=2, num_heads=6, coordinate=self.coordinate, trainable_vector=54)
        self.meso_dropout = nn.Dropout(0.2)
        # Global GCN
        # self.embed = nn.Linear(5, 30)
        self.global_layer_1 = GlobalLayer(30, 40)
        # self.global_embed = nn.Linear(40, 30)
        # self.global_layer_2 = GlobalLayer(self.args, 30, 40)
        # self.global_dropout = nn.Dropout(0.5)

        # mlp
        self.mlp0 = nn.Linear(71 * 70, 2048)
        self.mlp1 = nn.Linear(2048, 1024)
        self.logits = nn.Linear(1024, self.nclass)

        # common
        # self.layer_norm = nn.LayerNorm([30])
        self.bn = nn.BatchNorm1d(1024)
        self.lrelu = nn.LeakyReLU(self.l_relu)
        self.dropout = nn.Dropout(self.dropout)
        # self.att_dropout = nn.Dropout(0.9)

    def forward(self, x):
        # #############################################
        # # step1:Local GCN
        # #############################################
        lap_matrix = normalize_adj(self.adj)
        laplacian = lap_matrix
        # import pdb; pdb.set_trace()
        local_gcn_x = stratified_norm(F.leaky_relu(x.reshape(x.shape[0], -1))).reshape(x.shape[0], 62, -1)

        local_x1 = self.lrelu(self.local_gcn_1(local_gcn_x, laplacian, True))
        local_x1_norm = stratified_norm(F.leaky_relu(local_x1.reshape(x.shape[0], -1))).reshape(x.shape[0], 62, -1)
        local_x2 = self.lrelu(self.local_gcn_2(local_x1_norm, laplacian, True))
        res_local = torch.cat((local_gcn_x, local_x1_norm, local_x2), 2)
        if "local" not in self.module:
            self.module += "local "
        ##########################################
        #          step2:mesoscopic scale
        ##########################################
        # import pdb; pdb.set_trace()
        meso_input = self.meso_embed(local_gcn_x)  # 使用原始的feature 作为meso层的输入
        meso_input = self.meso_dropout(meso_input)
        coarsen_x1, coarsen_coor1 = self.meso_layer_1(meso_input)
        coarsen_x1 = self.lrelu(coarsen_x1)

        coarsen_x2, coarsen_coor2 = self.meso_layer_2(meso_input)
        coarsen_x2 = self.lrelu(coarsen_x2)
        # import pdb; pdb.set_trace()
        # current_batch_size = coarsen_coor1.size()[0]
        # initial_coordinate = self.coordinate.repeat(current_batch_size, 1, 1)
        res_meso = torch.cat((res_local, coarsen_x1, coarsen_x2), 1)
        res_coor = torch.cat((self.coordinate, coarsen_coor1, coarsen_coor2), 0)
        if "meso" not in self.module:
            self.module += "meso"
        #############################################
        # step3:global scale
        #############################################

        # current_batch_size = res_local.size()[0]
        # initial_coordinate = self.coordinate.repeat(current_batch_size, 1, 1)
        global_x1 = self.lrelu(self.global_layer_1(res_meso, res_coor))
        # global_x2 = self.lrelu(self.global_layer_2(self.global_embed(global_x1), res_coor))
        res_global = torch.cat((res_meso, global_x1), 2)
        if "global" not in self.module:
            self.module += "global"

        # ############################################
        # step4:emotion recognition
        # ############################################
        x = res_global.view(res_global.size(0), -1)
        x = self.lrelu(self.mlp0(x))
        x = self.dropout(x)
        # x = self.bn(x)
        x = self.lrelu(self.mlp1(x))
        logits = self.bn(x)
        if self.training_model == "self_supervised":
            return logits, lap_matrix, ""
        else:
            logits = self.logits(logits)
            return logits, lap_matrix, ""


class ARSCL(nn.Module):
    """
    使用查询编码器、键编码器和队列构建 MoCo 模型
    """

    def __init__(self, encoder, Config, local_adj, coor, k=1024, m=0.99, T1=0.1, T2=0.05, nn_num=5,
                 train_model='self_supervised',
                 use_soft_CL=True):
        super(ARSCL, self).__init__()
        self.T2 = T2
        self.T1 = T1
        self.K = k
        self.nn_num = nn_num  # K nearest neighbors
        self.m = m
        self.use_soft_CL = use_soft_CL
        self.train_model = train_model

        self.encoder_q = encoder(Config, local_adj, coor, train_model)
        self.encoder_k = encoder(Config, local_adj, coor, train_model)

        for param_q, param_k in zip(self.encoder_q.parameters(), self.encoder_k.parameters()):
            param_k.data.copy_(param_q.data)
            param_k.requires_grad = False

        # 创建一个新的队列
        self.register_buffer("queue", torch.randn(1024, k))
        # self.register_buffer("queue", torch.randn(310, k))
        self.queue = nn.functional.normalize(self.queue, dim=0)
        # 创建label队列
        self.register_buffer("labels", -1 * torch.ones(self.K).long())
        self.register_buffer("queue_ptr", torch.zeros(1, dtype=torch.long))
        self.max_entropy = np.log(self.K)

    # 使用装饰器 @torch.no_gard()
    @torch.no_grad()
    def _momentum_update_key_encoder(self):
        """
        动量键编码器的更新
        """
        for param_q, param_k in zip(self.encoder_q.parameters(), self.encoder_k.parameters()):
            param_k.data = param_k.data * self.m + param_q.data * (1. - self.m)

    @torch.no_grad()
    def _dequeue_and_enqueue(self, keys):
        batch_size = keys.shape[0]
        # 在更新队列之前获取键指针
        ptr = int(self.queue_ptr)
        assert self.K % batch_size == 0  # for simplicity

        # replace the keys at ptr (dequeue and enqueue)
        self.queue[:, ptr:ptr + batch_size] = keys.t()  # transpose
        # self.labels[ptr:ptr + batch_size] = labels

        ptr = (ptr + batch_size) % self.K  # move pointer

        self.queue_ptr[0] = ptr

    @torch.no_grad()
    def _batch_shuffle_single_gpu(self, x):
        """
        Batch shuffle, for making use of BatchNorm.
        """
        # random shuffle index
        idx_shuffle = torch.randperm(x.shape[0]).cuda()

        # index for restoring
        idx_unshuffle = torch.argsort(idx_shuffle)

        return x[idx_shuffle], idx_unshuffle

    @torch.no_grad()
    def _batch_unshuffle_single_gpu(self, x, idx_unshuffle):
        """
        Undo batch shuffle.
        """
        return x[idx_unshuffle]

    def forward(self, im_q, im_k):

        # compute query features
        # import pdb; pdb.set_trace()
        out_query, lap, fused_feature = self.encoder_q(im_q)
        # im_q.shape = (batch_size, channels, seq_len)  in_query:shape = (batch_size, features)
        query = nn.functional.normalize(out_query, dim=1)
        if self.train_model == 'self_supervised':
            with torch.no_grad():
                self._momentum_update_key_encoder()  # update the key encoder
                # shuffle for making use of BN
                im_k, idx_unshuffle = self._batch_shuffle_single_gpu(im_k)
                out_key, _, _ = self.encoder_k(im_k)  # keys: NxC
                key = nn.functional.normalize(out_key, dim=1)
                # undo shuffle
                key = self._batch_unshuffle_single_gpu(key, idx_unshuffle)
                # --- SCL ---
                if self.use_soft_CL:
                    # Adaptive soft_CL
                    logits_pd = torch.einsum('nc,ck->nk', [key, self.queue.clone().detach()])
                    logits_pd /= self.T2
                    labels = torch.zeros(logits_pd.size(0), logits_pd.size(1) + 1).cuda()
                    labels[:, 0] = 1.0
                    pseudo_labels = F.softmax(logits_pd, 1)
                    log_pseudo_labels = F.log_softmax(logits_pd, 1)
                    entropy = -torch.sum(pseudo_labels * log_pseudo_labels, dim=1, keepdim=True)
                    c = 1 - entropy / self.max_entropy
                    pseudo_labels = self.nn_num * c * pseudo_labels
                    pseudo_labels = torch.minimum(pseudo_labels, torch.tensor(1).to(pseudo_labels.device))
                    labels[:, 1:] = pseudo_labels

                    labels = labels / labels.sum(dim=1, keepdim=True)
                else:
                    labels = torch.zeros(im_q.shape[0], self.K + 1).cuda()

            # for KL loss
            # import pdb; pdb.set_trace()
            logitsq = torch.einsum('nc,ck->nk', [query, self.queue.clone().detach()])
            logitsk = torch.einsum('nc,ck->nk', [key, self.queue.clone().detach()])
            # positive logits: Nx1
            l_pos = torch.einsum('nc,nc->n', [query, key]).unsqueeze(-1)
            # negative logits: NxK
            l_neg = torch.einsum('nc,ck->nk', [query, self.queue.clone().detach()])
            # logits: Nx(1+K)
            logits = torch.cat([l_pos, l_neg], dim=1)
            logits /= self.T1
            #  --- Moco ---- #
            # labels = torch.zeros(logits.shape[0], dtype=torch.long).cuda()
            self._dequeue_and_enqueue(key)

            return logitsq, logitsk, logits, labels
        else:
            return out_query, lap, fused_feature


if __name__ == '__main__':
    config = Configs()
    # 局部视野的邻接矩阵
    adj_matrix = Parameter(torch.FloatTensor(convert_dis_m(get_ini_dis_m(), 9))).cuda()
    # 返回节点的绝对坐标
    coordinate_matrix = torch.FloatTensor(return_coordinates()).cuda()
    model = ARSCL(PGCN, config, adj_matrix, coordinate_matrix, train_model='supervised', use_soft_CL=True).cuda()
    input = torch.randn(32, 62, 5).cuda()
    out = model(input, input)
    import pdb;

    pdb.set_trace()
