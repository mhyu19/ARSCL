import torch.nn as nn
import torch
import torch.nn.functional as F
import numpy as np
from .attention import Seq_Transformer


class CNN_Model(nn.Module):
    def __init__(self, configs, model='self_supervised'):
        super(CNN_Model, self).__init__()

        self.train_model = model
        self.num_channels = configs.final_out_channels
        self.conv_block1 = nn.Sequential(
            nn.Conv1d(configs.input_channels, 32, kernel_size=configs.kernel_size,
                      stride=configs.stride, bias=False, padding=(configs.kernel_size // 2)),
            nn.BatchNorm1d(32),
            nn.ReLU(),
            nn.MaxPool1d(kernel_size=2, stride=2, padding=1),
            nn.Dropout(configs.dropout)
        )

        self.conv_block2 = nn.Sequential(
            nn.Conv1d(32, 64, kernel_size=configs.kernel_size, stride=1, bias=False, padding=1),
            nn.BatchNorm1d(64),
            nn.ReLU(),
            nn.MaxPool1d(kernel_size=2, stride=2, padding=1)
        )

        self.conv_block3 = nn.Sequential(
            nn.Conv1d(64, configs.final_out_channels, kernel_size=configs.kernel_size, stride=1, bias=False, padding=1),
            nn.BatchNorm1d(configs.final_out_channels),
            nn.ReLU(),
            nn.MaxPool1d(kernel_size=2, stride=2, padding=1),
        )
        # self.seq_transformer = Seq_Transformer(patch_size=self.num_channels, dim=configs.TC.hidden_dim, depth=4,
        #                                        heads=4, mlp_dim=64)

        self.logits = nn.Linear(configs.final_out_channels*configs.features_len, configs.num_classes)

    def forward(self, x_in):
        x = self.conv_block1(x_in)
        x = self.conv_block2(x)
        x = self.conv_block3(x)   # shape = (batch_size, final_out_channels, Feature) torch.Size([64, 128, 6])
        x_flat = x.reshape(x.shape[0], -1)
        # import pdb; pdb.set_trace()
        # x = self.seq_transformer(x.transpose(1, 2))  # latent vector
        # shape = (batch_size, output)
        if self.train_model == 'self_supervised':
            logits = x_flat
        else:
            logits = self.logits(x_flat)
        return logits, logits


class ARSCL(nn.Module):
    """
    使用查询编码器、键编码器和队列构建 MoCo 模型
    """

    def __init__(self, model, Config, k=1024, m=0.99, T1=0.1, T2=0.05, nn_num=5, train_model='self_supervised',
                 use_soft_CL=True):
        super(ARSCL, self).__init__()
        self.T2 = T2
        self.T1 = T1
        self.K = k
        self.nn_num = nn_num   # K nearest neighbors
        self.m = m
        self.use_soft_CL = use_soft_CL
        self.train_model = train_model

        self.encoder_q = model(Config, train_model)
        self.encoder_k = model(Config, train_model)

        for param_q, param_k in zip(self.encoder_q.parameters(), self.encoder_k.parameters()):
            param_k.data.copy_(param_q.data)
            param_k.requires_grad = False

        # 创建一个新的队列
        # self.register_buffer("queue", torch.randn(Config.TC.hidden_dim, k))
        self.register_buffer("queue", torch.randn(Config.final_out_channels*Config.features_len, k))
        self.queue = nn.functional.normalize(self.queue, dim=0)
        # 创建label队列
        self.register_buffer("labels", -1 * torch.ones(self.K).long())
        self.register_buffer("queue_ptr", torch.zeros(1, dtype=torch.long))
        self.max_entropy = np.log(self.K)

    # 使用装饰器 @torch.no_gard()
    @torch.no_grad()
    def _momentum_update_key_encoder(self):
        """
        动量键编码器的更新
        """
        for param_q, param_k in zip(self.encoder_q.parameters(), self.encoder_k.parameters()):
            param_k.data = param_k.data * self.m + param_q.data * (1. - self.m)

    @torch.no_grad()
    def _dequeue_and_enqueue(self, keys):
        batch_size = keys.shape[0]
        # 在更新队列之前获取键指针
        ptr = int(self.queue_ptr)
        # import pdb; pdb.set_trace()
        assert self.K % batch_size == 0  # for simplicity

        # replace the keys at ptr (dequeue and enqueue)
        self.queue[:, ptr:ptr + batch_size] = keys.t()  # transpose
        # self.labels[ptr:ptr + batch_size] = labels

        ptr = (ptr + batch_size) % self.K  # move pointer

        self.queue_ptr[0] = ptr

    @torch.no_grad()
    def _batch_shuffle_single_gpu(self, x):
        """
        Batch shuffle, for making use of BatchNorm.
        """
        # random shuffle index
        idx_shuffle = torch.randperm(x.shape[0]).cuda()

        # index for restoring
        idx_unshuffle = torch.argsort(idx_shuffle)

        return x[idx_shuffle], idx_unshuffle

    @torch.no_grad()
    def _batch_unshuffle_single_gpu(self, x, idx_unshuffle):
        """
        Undo batch shuffle.
        """
        return x[idx_unshuffle]

    def forward(self, im_q, im_k):

        # import pdb; pdb.set_trace()
        outputs, out_query = self.encoder_q(im_q)
        # im_q.shape = (batch_size, channels, seq_len)  in_query:shape = (batch_size, features)
        query = nn.functional.normalize(out_query, dim=1)
        if self.train_model == 'self_supervised':
            with torch.no_grad():
                self._momentum_update_key_encoder()  # update the key encoder
                # shuffle for making use of BN
                im_k, idx_unshuffle = self._batch_shuffle_single_gpu(im_k)
                _, out_key = self.encoder_k(im_k)  # keys: NxC
                key = nn.functional.normalize(out_key, dim=1)
                # undo shuffle
                key = self._batch_unshuffle_single_gpu(key, idx_unshuffle)
                # --- SCL ---
                if self.use_soft_CL:
                    # Adaptive soft_CL
                    logits_pd = torch.einsum('nc,ck->nk', [key, self.queue.clone().detach()])
                    logits_pd /= self.T2
                    labels = torch.zeros(logits_pd.size(0), logits_pd.size(1) + 1).cuda()
                    labels[:, 0] = 1.0
                    pseudo_labels = F.softmax(logits_pd, 1)
                    pseudo_labels = torch.minimum(pseudo_labels, torch.tensor(1).to(pseudo_labels.device))
                    labels[:, 1:] = pseudo_labels
                    labels = labels / labels.sum(dim=1, keepdim=True)
                else:
                    #  --- Moco ---- #
                    labels = torch.zeros(im_q.shape[0], self.K + 1).cuda()

            # for KL loss
            # import pdb; pdb.set_trace()
            logitsq = torch.einsum('nc,ck->nk', [query, self.queue.clone().detach()])
            logitsk = torch.einsum('nc,ck->nk', [key, self.queue.clone().detach()])
            # positive logits: Nx1
            l_pos = torch.einsum('nc,nc->n', [query, key]).unsqueeze(-1)
            # negative logits: NxK
            l_neg = torch.einsum('nc,ck->nk', [query, self.queue.clone().detach()])
            # logits: Nx(1+K)
            logits = torch.cat([l_pos, l_neg], dim=1)
            logits /= self.T1
            self._dequeue_and_enqueue(key)

            return logitsq, logitsk, logits, labels
        else:
            return outputs, out_query

